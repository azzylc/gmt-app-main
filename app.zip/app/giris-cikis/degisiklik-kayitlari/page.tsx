"use client";
import { useState, useEffect } from "react";
import { auth, db } from "../../lib/firebase";
import { onAuthStateChanged } from "firebase/auth";
import { collection, query, onSnapshot, orderBy, where, Timestamp } from "firebase/firestore";
import { useRouter } from "next/navigation";
import Sidebar from "../../components/Sidebar";

interface DegisiklikKaydi {
  id: string;
  degisiklikYapan: string;
  degisiklikTarihi: any;
  degisiklikTuru: string;
  oncekiDeger: string;
  sonrakiDeger: string;
  kullaniciAdi: string;
  konum: string;
  girisCikisTarih: any;
}

export default function DegisiklikKayitlariPage() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [kayitlar, setKayitlar] = useState<DegisiklikKaydi[]>([]);
  const [filteredKayitlar, setFilteredKayitlar] = useState<DegisiklikKaydi[]>([]);
  const router = useRouter();

  // Filtreler
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("Tümünde");

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setUser(user);
      } else {
        router.push("/login");
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, [router]);

  // Değişiklik kayıtlarını çek
  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, "attendanceChanges"),
      orderBy("degisiklikTarihi", "desc")
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data: DegisiklikKaydi[] = [];
      snapshot.forEach((doc) => {
        const d = doc.data();
        data.push({
          id: doc.id,
          degisiklikYapan: d.degisiklikYapan || "",
          degisiklikTarihi: d.degisiklikTarihi,
          degisiklikTuru: d.degisiklikTuru || "",
          oncekiDeger: d.oncekiDeger || "",
          sonrakiDeger: d.sonrakiDeger || "",
          kullaniciAdi: d.kullaniciAdi || "",
          konum: d.konum || "",
          girisCikisTarih: d.girisCikisTarih
        });
      });
      setKayitlar(data);
    });

    return () => unsubscribe();
  }, [user]);

  // Filtreleme
  useEffect(() => {
    let filtered = [...kayitlar];

    if (searchTerm) {
      filtered = filtered.filter(k => 
        k.degisiklikYapan.toLowerCase().includes(searchTerm.toLowerCase()) ||
        k.kullaniciAdi.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (filterType !== "Tümünde") {
      filtered = filtered.filter(k => k.degisiklikTuru === filterType);
    }

    setFilteredKayitlar(filtered);
  }, [kayitlar, searchTerm, filterType]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-pink-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Sidebar user={user} />

      <div className="md:ml-64 pb-20 md:pb-0">
        <header className="bg-white border-b px-4 md:px-6 py-4 sticky top-0 z-30">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-xl font-bold text-gray-800">Değişiklik Kayıtları</h1>
              <p className="text-sm text-gray-500 mt-1">Bu sayfada, giriş - çıkış işlemleri üzerinde yapılan işlemlerin kayıtlarını görüntüleyebilirsiniz.</p>
            </div>
            <button
              onClick={() => window.print()}
              className="bg-pink-500 hover:bg-pink-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition flex items-center gap-2"
            >
              🖨️ Yazdır
            </button>
          </div>
        </header>

        <main className="p-4 md:p-6">
          {/* Filtreler */}
          <div className="bg-white rounded-xl shadow-sm border p-4 mb-6">
            <div className="flex flex-col md:flex-row gap-4">
              <input
                type="text"
                placeholder="Kullanıcı ara..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="flex-1 px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
              />
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
              >
                <option value="Tümünde">Tümünde</option>
                <option value="Kayıt Eklendi">Kayıt Eklendi</option>
                <option value="Kayıt Silindi">Kayıt Silindi</option>
              </select>
              <button className="bg-green-500 hover:bg-green-600 text-white px-6 py-2 rounded-lg font-medium transition">
                Ara
              </button>
            </div>
          </div>

          {/* Tablo */}
          <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">#</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Değişikliği Yapan</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">↓ Değişiklik Tarihi</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Değişiklik Türü</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Değişiklik Öncesi</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Değişiklik Sonrası</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Kullanıcı Adı</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Konum</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Giriş / Çıkış Tarih</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {filteredKayitlar.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="px-4 py-12 text-center text-gray-500">
                        Değişiklik kaydı bulunamadı
                      </td>
                    </tr>
                  ) : (
                    filteredKayitlar.map((kayit, index) => {
                      const degisiklikTarihi = kayit.degisiklikTarihi?.toDate?.() ? kayit.degisiklikTarihi.toDate() : new Date();
                      const girisCikisTarihi = kayit.girisCikisTarih?.toDate?.() ? kayit.girisCikisTarih.toDate() : null;
                      
                      return (
                        <tr key={kayit.id} className="hover:bg-gray-50">
                          <td className="px-4 py-3 text-sm text-gray-600">{index + 1}</td>
                          <td className="px-4 py-3 text-sm text-gray-600">{kayit.degisiklikYapan}</td>
                          <td className="px-4 py-3 text-sm text-gray-600">
                            {degisiklikTarihi.toLocaleDateString('tr-TR')} {degisiklikTarihi.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                          </td>
                          <td className="px-4 py-3">
                            <span className={`inline-flex px-2 py-1 rounded text-xs font-medium ${
                              kayit.degisiklikTuru === "Kayıt Eklendi" 
                                ? "bg-green-100 text-green-700" 
                                : kayit.degisiklikTuru === "Kayıt Silindi"
                                ? "bg-red-100 text-red-700"
                                : "bg-gray-100 text-gray-700"
                            }`}>
                              {kayit.degisiklikTuru}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-sm text-gray-600">{kayit.oncekiDeger || "-"}</td>
                          <td className="px-4 py-3">
                            {kayit.sonrakiDeger ? (
                              <span className={`inline-flex px-2 py-1 rounded text-xs font-medium ${
                                kayit.sonrakiDeger === "Giriş" 
                                  ? "bg-green-100 text-green-700" 
                                  : kayit.sonrakiDeger === "Çıkış"
                                  ? "bg-red-100 text-red-700"
                                  : "bg-gray-100 text-gray-700"
                              }`}>
                                {kayit.sonrakiDeger}
                              </span>
                            ) : "-"}
                          </td>
                          <td className="px-4 py-3 text-sm font-medium text-gray-800">{kayit.kullaniciAdi}</td>
                          <td className="px-4 py-3 text-sm text-gray-600">{kayit.konum || "-"}</td>
                          <td className="px-4 py-3 text-sm text-gray-600">
                            {girisCikisTarihi 
                              ? `${girisCikisTarihi.toLocaleDateString('tr-TR')} ${girisCikisTarihi.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}`
                              : "-"
                            }
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}