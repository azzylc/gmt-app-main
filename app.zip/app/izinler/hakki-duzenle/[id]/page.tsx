"use client";
import { useState, useEffect } from "react";
import { useRouter, useParams } from "next/navigation";
import { auth, db } from "../../../lib/firebase";
import { onAuthStateChanged } from "firebase/auth";
import { doc, getDoc, updateDoc } from "firebase/firestore";
import Sidebar from "../../../components/Sidebar";

export default function IzinHakkiDuzenle() {
  const router = useRouter();
  const params = useParams();
  const kayitId = params.id as string;

  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // Form state
  const [personelAd, setPersonelAd] = useState("");
  const [personelSoyad, setPersonelSoyad] = useState("");
  const [hakGunu, setHakGunu] = useState("");
  const [aciklama, setAciklama] = useState("");

  // Enter ile kaydet (textarea hariç)
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && e.target instanceof HTMLInputElement) {
      e.preventDefault();
      handleSave();
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setUser(user);
      } else {
        router.push("/login");
      }
    });
    return () => unsubscribe();
  }, [router]);

  // Kayıt verilerini çek
  useEffect(() => {
    if (!user || !kayitId) return;

    const fetchKayit = async () => {
      try {
        const docRef = doc(db, "izinHakDegisiklikleri", kayitId);
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
          const data = docSnap.data();
          setPersonelAd(data.personelAd || "");
          setPersonelSoyad(data.personelSoyad || "");
          setHakGunu(data.eklenenGun?.toString() || "");
          setAciklama(data.aciklama || "");
        } else {
          alert("Kayıt bulunamadı.");
          router.push("/izinler/haklar");
        }
      } catch (error) {
        console.error("Veri çekme hatası:", error);
        alert("Veri yüklenirken hata oluştu.");
      } finally {
        setLoading(false);
      }
    };

    fetchKayit();
  }, [user, kayitId, router]);

  const handleSave = async () => {
    if (!hakGunu || parseInt(hakGunu) <= 0) {
      alert("Lütfen geçerli bir gün sayısı girin.");
      return;
    }
    if (!aciklama.trim()) {
      alert("Lütfen kısa açıklama girin.");
      return;
    }

    setSaving(true);

    try {
      const docRef = doc(db, "izinHakDegisiklikleri", kayitId);
      await updateDoc(docRef, {
        eklenenGun: parseInt(hakGunu),
        aciklama: aciklama.trim(),
        sonDuzenlemeTarihi: new Date().toISOString(),
        sonDuzenleyen: user?.email || "",
      });

      alert("Kayıt başarıyla güncellendi.");
      router.push("/izinler/haklar");
    } catch (error) {
      console.error("Güncelleme hatası:", error);
      alert("Güncelleme işlemi başarısız oldu.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-neutral-warm">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500"></div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-neutral-warm">
      <Sidebar user={user} />

      <main className="flex-1 p-4 lg:p-6 md:ml-64 pb-20 md:pb-0">
        {/* Header */}
        <div className="mb-6 flex items-start justify-between">
          <div>
            <h1 className="text-xl font-bold text-gray-800">İzin Hakkı Düzenle</h1>
            <p className="text-sm text-gray-500">
              İzin hakkı kaydını düzenleyebilirsiniz.
            </p>
          </div>

          {/* Top Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleSave}
              disabled={saving}
              className="px-4 py-2 bg-primary-500 text-white rounded-lg text-sm font-medium hover:bg-primary-600 transition-colors flex items-center gap-2 disabled:opacity-50"
            >
              <span>💾</span>
              <span>Kaydet</span>
            </button>
            <button
              onClick={() => router.back()}
              className="px-4 py-2 bg-primary-400 text-white rounded-lg text-sm font-medium hover:bg-primary-500 transition-colors flex items-center gap-2"
            >
              <span>↩</span>
              <span>Geri dön</span>
            </button>
          </div>
        </div>

        {/* Form Card */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-100" onKeyDown={handleKeyDown}>
          {/* Tab Header */}
          <div className="border-b border-gray-100 px-6 pt-4">
            <div className="inline-block">
              <span className="text-primary-500 font-medium text-sm pb-3 block border-b-2 border-primary-500">
                Genel
              </span>
            </div>
          </div>

          {/* Form Content */}
          <div className="p-6 space-y-6">
            {/* Kullanıcı (readonly) */}
            <div className="grid grid-cols-[200px_1fr] items-center gap-4">
              <label className="text-sm font-medium text-gray-700">
                Kullanıcı
              </label>
              <div className="px-3 py-2 bg-gray-100 rounded-lg text-sm text-gray-700 w-full max-w-md">
                {personelAd} {personelSoyad}
              </div>
            </div>

            {/* Hak kazandığı gün */}
            <div className="grid grid-cols-[200px_1fr] items-center gap-4">
              <label className="text-sm font-medium text-gray-700">
                Hak kazandığı gün <span className="text-red-500">(*)</span>
              </label>
              <input
                type="number"
                min="1"
                value={hakGunu}
                onChange={(e) => setHakGunu(e.target.value)}
                placeholder="Örn: 14"
                className="w-full max-w-md px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500"
              />
            </div>

            {/* Kısa Açıklama */}
            <div className="grid grid-cols-[200px_1fr] items-start gap-4">
              <label className="text-sm font-medium text-gray-700 pt-2">
                Kısa Açıklama <span className="text-red-500">(*)</span>
              </label>
              <textarea
                value={aciklama}
                onChange={(e) => setAciklama(e.target.value)}
                placeholder="Örn: 2025 yılı yıllık izin hakkı"
                rows={5}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 resize-y"
              />
            </div>
          </div>
        </div>

        {/* Bottom Action Buttons */}
        <div className="mt-6 flex items-center justify-end gap-2">
          <button
            onClick={handleSave}
            disabled={saving}
            className="px-4 py-2 bg-primary-500 text-white rounded-lg text-sm font-medium hover:bg-primary-600 transition-colors flex items-center gap-2 disabled:opacity-50"
          >
            <span>💾</span>
            <span>Kaydet</span>
          </button>
          <button
            onClick={() => router.back()}
            className="px-4 py-2 bg-primary-400 text-white rounded-lg text-sm font-medium hover:bg-primary-500 transition-colors flex items-center gap-2"
          >
            <span>↩</span>
            <span>Geri dön</span>
          </button>
        </div>
      </main>
    </div>
  );
}