import * as admin from 'firebase-admin';

// Firebase Admin SDK'yı initialize et
if (!admin.apps.length) {
  const serviceAccount = JSON.parse(
    process.env.FIREBASE_SERVICE_ACCOUNT_KEY || '{}'
  );

  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  });
}

// Firestore instance
export const adminDb = admin.firestore();

// Auth instance
export const adminAuth = admin.auth();

export default admin;
